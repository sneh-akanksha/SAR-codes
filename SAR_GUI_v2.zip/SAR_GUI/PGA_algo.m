function[s_mf_time_new] =  PGA_algo(s_mf_time,t_fast,t_slow)
% Phase Gradient Autofocus algorithm
cr = s_mf_time;
for i=1:length(t_fast) %circshift of max scatters in range profile domain
[~, linIndex] = max(cr(:,i));
[row, col] = ind2sub(size(cr), linIndex);
sar2(:,i) = circshift(cr(:,i),[(0.5*(length(t_slow)))-row,0]);
end

sar2 = sar2.*(kaiser(length(t_slow),0.5)*ones(1,length(t_fast))); % windowing/LPF
sar2 = sar2.';

phi = zeros(length(t_slow),1);
for n=1:length(t_slow)-1
for n_ = 1:n
    d_phi = sar2(:,n_)' * sar2(:,n_+1);
    phi(n+1,1) = phi(n+1,1)+d_phi;
end
end
% disp(angle(phi))
for n=1:length(t_slow)
    s_mf_time_new(n,:) = s_mf_time(n,:)*exp(-1j*angle(phi(n,1)));
end